// DBCallback.java

package com.mongodb;


import org.bson.*;

/**
 * The DB callback interface.
 */
public interface DBCallback extends BSONCallback {

}

