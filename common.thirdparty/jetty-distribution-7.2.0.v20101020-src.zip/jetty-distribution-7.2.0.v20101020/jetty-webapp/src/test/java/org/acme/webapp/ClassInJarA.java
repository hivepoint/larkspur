package org.acme.webapp;

public class ClassInJarA
{
    public static final boolean FROM_PARENT=true; 
}
