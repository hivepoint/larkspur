package com.google.appengine.api.labs.modules;

/**
 * {@link IModulesFactory} for Google AppEngine.
 *
 */
public final class ModulesServiceFactoryImpl implements IModulesServiceFactory {
  @Override
  public ModulesService getModulesService() {
    return new ModulesServiceImpl();
  }
}
