package com.google.appengine.api.labs.modules;

/**
 * Interface for the {@link ModulesService} plugin for
 * {@link com.google.appengine.spi.ServiceFactoryFactory}.
 *
 */
public interface IModulesServiceFactory {
  /**
   * Creates and returns a {@link ModulesService}.
   */
  public ModulesService getModulesService();
}
