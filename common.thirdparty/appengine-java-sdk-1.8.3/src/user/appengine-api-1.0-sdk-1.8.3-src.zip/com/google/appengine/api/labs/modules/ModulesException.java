package com.google.appengine.api.labs.modules;

/**
 * Exception thrown by the {@link ModulesService}.
 *
 */
public class ModulesException extends RuntimeException {

  ModulesException(String detail) {
    super(detail);
  }
}
